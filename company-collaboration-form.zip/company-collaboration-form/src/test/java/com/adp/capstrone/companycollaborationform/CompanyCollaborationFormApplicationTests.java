package com.adp.capstrone.companycollaborationform;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.util.Assert;

import com.adp.capstrone.companycollaborationform.model.Post;
import com.adp.capstrone.companycollaborationform.model.Users;
import com.adp.capstrone.companycollaborationform.repo.PostRepo;
import com.adp.capstrone.companycollaborationform.repo.PostRepoId;
import com.adp.capstrone.companycollaborationform.repo.UserRepo;

@SpringBootTest
class CompanyCollaborationFormApplicationTests {
	
	@Autowired
	private UserRepo userRepo;

	@Test
    @Order(1)
    @Rollback(value = false)
	void saveUserTest() {
		Users user=new Users("test","case","test@case.com","Test@123");
	    userRepo.save(user);
	    Users saveData=userRepo.findByEmail("test@case.com");
	    assertEquals(user.getEmail(),saveData.getEmail());
	    assertEquals(user.getFname(),saveData.getFname());
	    assertEquals(user.getLname(),saveData.getLname());
	    assertEquals(user.getPassword(),saveData.getPassword());
	    
	    }
	@Test
    @Order(2)
    public void getUserTest(){
		Users user=userRepo.findByEmail("test@case.com");
		assertEquals(user.getEmail(),"test@case.com");

    }

    @Test
    @Order(3)
    public void getListOfUserTest(){

        List<Users> user = userRepo.findAll();
        assertNotNull(user);

    }

    @Test
    @Order(4)
    @Rollback(value = false)
    public void updateUserTest(){
    	Users user=userRepo.findByEmail("test@case.com");
        user.setEmail("ram@gmail.com");
        userRepo.update(user);
	    
    }
    
   
       

}
	


