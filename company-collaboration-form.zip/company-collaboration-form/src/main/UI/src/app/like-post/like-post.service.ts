import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LikePostService {

  private resultUrl: string;

  constructor(private httpClient:HttpClient) { 
    this.resultUrl = 'http://localhost:8080/api/like/';
  }
  checkNotLikeUserSave(email,post_id):Observable<Object>{   
    console.log("calling api"+post_id+email);
    let url='http://localhost:8080/api/like/'+post_id+"/"+email
    return this.httpClient.get(url);
  }
  numberOfLike(post_id:number):Observable<Object>{     
    return this.httpClient.get('http://localhost:8080/api/like/'+post_id);
  }
}
