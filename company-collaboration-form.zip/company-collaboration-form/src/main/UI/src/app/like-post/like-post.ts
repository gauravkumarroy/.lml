export class LikePost {
    email:string;
    post_id:number;
}
