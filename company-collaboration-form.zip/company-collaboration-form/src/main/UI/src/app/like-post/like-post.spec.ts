import { LikePost } from './like-post';

describe('LikePost', () => {
  it('should create an instance', () => {
    expect(new LikePost()).toBeTruthy();
  });
});
