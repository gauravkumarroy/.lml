import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CreatePostService } from '../create-post/create-post.service';
import { Post } from '../create-post/post';
import { FolloweeService } from '../followee/followee.service';
import { FollowerService } from '../follower-list/follower.service';
import { LikePostService } from '../like-post/like-post.service';
import { User } from '../registration/user';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  posts:Post[]=[];
  loading=true;
  email:string;
  curr: Date = new Date();
  date: Date;
  followerEmail:string[];
  followerList:User[]|undefined;
  nodata=false;
  constructor(
    private createPostService: CreatePostService,
    private router:Router,
    private followeeService:FollowerService,
    private likePost:LikePostService,

    ) { 
      this.loading=true;
  }

  ngOnInit(): void {
    this.loading=true;
    this.email=JSON.parse(localStorage.getItem('user')).email;
    this.followeeService.getFollower(this.email).subscribe((data:User) => {
      if(Object.keys(data).length==0){
        this.nodata=true;
        this.loading=false;
      }
      else{
        for(let i=0;i<Object.keys(data).length;i++){
          console.log(data[i].email)
          this.createPostService.getPostsByEmail(data[i].email).subscribe((datas) => {
            console.log(datas)
            this.posts.push(datas)
          });
        }
        this.loading=false;
      } 
      console.log("final data")
      console.log(this.posts)
        }); 
     
  }

  like(post){
    this.likePost.checkNotLikeUserSave(this.email,post.id).subscribe((data) => {
      alert("You liked the post");
      this.likeCount(post?.id);
    },(error)=>{
      this.likeCount(post?.id);
    });
  }
  comment(post){
    localStorage.setItem('post',JSON.stringify(post));
    this.router.navigate(['comment']);
    console.log(post);
  }
  likeCount(id){
    this.likePost.numberOfLike(id).subscribe((data) => {
      console.log("data",data,"type",typeof data);
      alert(data);
    },(error)=>{
      alert("Some error happend while fetching the likes");  
    });

  }

  calcDate(date2) {
    this.date = new Date(date2);
    var message=''
    var diff = Math.floor(this.curr.getTime()/1000 - this.date.getTime()/1000);
    const Days = Math.floor( diff / (60 * 60 * 24) );
        const Hour = Math.floor((diff % (60 * 60 * 24)) / (60 * 60));
        const Minutes = Math.floor(((diff % (60 * 60 * 24)) % (60 * 60)) / 60 );
        const Seconds = Math.floor(((diff % (60 * 60 * 24)) % (60 * 60)) % 60 );
        if (Days > 0){
          message += Days + ' Day ago';
        }
        else if (Hour > 0){
          message += Hour + ' Hour ago';
        }
        else if (Minutes > 0){
          message += Minutes + ' Minutes ago';
        }
        else if (Seconds > 0){
          message += Seconds + ' Seconds ago';
        }
        return message;
  }
}
