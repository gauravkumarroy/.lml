import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { FolloweeService } from '../followee/followee.service';
import { FollowerService } from '../follower-list/follower.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  name: any;
  email: any;
  follower: number;
  following: number;
  public userName: string;
  constructor(
    private authService: AuthService,
    private followeeService: FolloweeService,
    private followerService: FollowerService,
    private router: Router
  ) {}
  ngOnInit(): void {
    this.name =
      JSON.parse(localStorage.getItem('user')).fname +
      ' ' +
      JSON.parse(localStorage.getItem('user')).lname;
    this.email = JSON.parse(localStorage.getItem('user')).email;
    this.followeeService.getFollowee(this.email).subscribe((data) => {
      this.follower = Object.keys(data).length;
    });
    this.followerService.getFollower(this.email).subscribe((data) => {
      this.following = Object.keys(data).length;
    });
  }

  logout() {
    this.authService.logout();
    localStorage.removeItem('user');
    this.router.navigateByUrl('/login');
  }
}
