import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CreatePostService } from '../create-post/create-post.service';
import { Post } from '../create-post/post';

@Component({
  selector: 'app-view-post',
  templateUrl: './view-post.component.html',
  styleUrls: ['./view-post.component.css'],
})
export class ViewPostComponent implements OnInit {
  posts: any;
  nodata = false;
  result: Post[];
  email: string;
  curr: Date = new Date();
  date: Date;
  constructor(
    private createPostService: CreatePostService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.email = JSON.parse(localStorage.getItem('user')).email;
    this.createPostService.getPostsByEmail(this.email).subscribe((data) => {
      this.posts = data;
      if (Object.keys(this.posts).length === 0) {
        this.nodata = true;
      }
    });
  }

  calcDate(date2) {
    this.date = new Date(date2);
    var message = '';
    var diff = Math.floor(
      this.curr.getTime() / 1000 - this.date.getTime() / 1000
    );
    const Days = Math.floor(diff / (60 * 60 * 24));
    const Hour = Math.floor((diff % (60 * 60 * 24)) / (60 * 60));
    const Minutes = Math.floor(((diff % (60 * 60 * 24)) % (60 * 60)) / 60);
    const Seconds = Math.floor(((diff % (60 * 60 * 24)) % (60 * 60)) % 60);
    if (Days > 0) {
      message += Days + ' Day ago';
    } else if (Hour > 0) {
      message += Hour + ' Hour ago';
    } else if (Minutes > 0) {
      message += Minutes + ' Minutes ago';
    } else if (Seconds > 0) {
      message += Seconds + ' Seconds ago';
    }
    return message;
  }
  deletePost(event) {
    console.log(event);

    this.createPostService.deletePost(event.id).subscribe(
      (data) => {
        alert('Post Deleted successfully');
        this.ngOnInit();
      },
      (error) => {
        alert('Error occured while deleting post');
      }
    );
  }
  updatePost(event) {
    localStorage.setItem('post', JSON.stringify(event));
    this.router.navigate(['editpost']);
  }
}
