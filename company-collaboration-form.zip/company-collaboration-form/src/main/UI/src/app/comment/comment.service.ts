import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Commentclass } from './commentclass';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  private resultUrl: string;

  constructor(private httpClient:HttpClient) { 
    this.resultUrl = 'http://localhost:8080/api/comment';
  }

  createComment(co:Commentclass):Observable<Object>{   
    return this.httpClient.post(`${this.resultUrl}`,co);
  }
  getComment(post_id:number):Observable<Object>{     
    return this.httpClient.get('http://localhost:8080/api/comment/'+post_id);
  }
}
