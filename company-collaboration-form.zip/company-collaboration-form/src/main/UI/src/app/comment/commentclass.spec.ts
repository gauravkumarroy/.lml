import { Commentclass } from './commentclass';

describe('Commentclass', () => {
  it('should create an instance', () => {
    expect(new Commentclass()).toBeTruthy();
  });
});
