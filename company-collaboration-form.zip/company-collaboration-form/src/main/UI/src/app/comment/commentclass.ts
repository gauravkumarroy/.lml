export class Commentclass {
    post_id:string;
    email:string;
    comment:string;
    constructor(post_id,email,comments){
        this.email=email;
        this.comment=comments;
        this.post_id=post_id;
    }
}
