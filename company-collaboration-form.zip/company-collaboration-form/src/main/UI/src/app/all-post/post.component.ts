import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CreatePostService } from '../create-post/create-post.service';
import { Post } from '../create-post/post';
import { LikePostService } from '../like-post/like-post.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css'],
})
export class PostComponent implements OnInit {
  loading = false;
  posts: Post[] | undefined;
  email: string;
  curr: Date = new Date();
  date: Date;
  str: any;
  constructor(
    private createPostService: CreatePostService,
    private router: Router,
    private likePost: LikePostService
  ) {
    this.loading = true;
  }

  ngOnInit(): void {
    this.loading = true;
    this.email = JSON.parse(localStorage.getItem('user')).email;
    this.createPostService.getPosts().subscribe((data) => {
      this.posts = data;
    });
    this.loading = false;
  }

  likeds(post) {
    this.likePost.checkNotLikeUserSave(this.email, post.id).subscribe(
      (data) => {
        alert('You liked the post');
        this.likeCount(post?.id);
      },
      (error) => {
        this.likeCount(post?.id);
      }
    );
  }
  comment(post) {
    localStorage.setItem('post', JSON.stringify(post));
    this.router.navigate(['comment']);
  }
  async likeCount(post) {
    this.likePost.numberOfLike(post).subscribe(
      (data) => {
        console.log('data', data, 'type', typeof data);
        alert(data);
      },
      (error) => {
        alert('Some error happend while fetching the likes');
      }
    );
  }

  calcDate(date2) {
    this.date = new Date(date2);
    var message = '';
    var diff = Math.floor(
      this.curr.getTime() / 1000 - this.date.getTime() / 1000
    );
    const Days = Math.floor(diff / (60 * 60 * 24));
    const Hour = Math.floor((diff % (60 * 60 * 24)) / (60 * 60));
    const Minutes = Math.floor(((diff % (60 * 60 * 24)) % (60 * 60)) / 60);
    const Seconds = Math.floor(((diff % (60 * 60 * 24)) % (60 * 60)) % 60);
    if (Days > 0) {
      message += Days + ' Day ago';
    } else if (Hour > 0) {
      message += Hour + ' Hour ago';
    } else if (Minutes > 0) {
      message += Minutes + ' Minutes ago';
    } else if (Seconds > 0) {
      message += Seconds + ' Seconds ago';
    }
    return message;
  }
}
