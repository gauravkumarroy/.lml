export class LoginClass {
    email!:string;
    password!:string;
}
