import { LoginClass } from './login-class';

describe('LoginClass', () => {
  it('should create an instance', () => {
    expect(new LoginClass()).toBeTruthy();
  });
});
