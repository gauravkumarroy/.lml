export class Post {
    id: number|undefined ;
    title: string |undefined;
    email: string |undefined;
    createdAt: Date = new Date();
}
