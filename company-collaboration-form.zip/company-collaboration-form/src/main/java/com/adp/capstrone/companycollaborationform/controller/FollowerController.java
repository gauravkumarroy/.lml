package com.adp.capstrone.companycollaborationform.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adp.capstrone.companycollaborationform.model.Follower;
import com.adp.capstrone.companycollaborationform.model.Post;
import com.adp.capstrone.companycollaborationform.model.Users;
import com.adp.capstrone.companycollaborationform.repo.FollowerRepo;
import com.adp.capstrone.companycollaborationform.repo.FollowerRepoInt;
import com.adp.capstrone.companycollaborationform.repo.UserRepo;

@RestController
@RequestMapping("/apis")
@CrossOrigin(origins="http://localhost:4200")
public class FollowerController {
	
	@Autowired
	private FollowerRepo folowerRepo;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private FollowerRepoInt folowerRepoInt;
	
	@PostMapping("/followerList")
	public ResponseEntity<Optional<List<Users>>> followerList(@RequestBody String email){
    	List<Follower> ls=folowerRepo.findAll();
    	List<Users> result=new ArrayList<>();
    	 for(int i=0;i<ls.size();i++) {
    		if(ls.get(i).getFollowee().getEmail().equals(email)) {
    			Users u=ls.get(i).getFollower();
    			u.setPassword(ls.get(i).getId().toString());
    			result.add(u);	
    		}
    	 }
    	 
    	 return new ResponseEntity<Optional<List<Users>>>(Optional.ofNullable(result),HttpStatus.OK);
		
	}
	@DeleteMapping("/followerList/{id}")
	public ResponseEntity<HttpStatus> followerList(@PathVariable Long id){
    	if(folowerRepoInt.existsById(id)) {
    		folowerRepoInt.deleteById(id);
    		return new ResponseEntity<HttpStatus>(HttpStatus.OK);
    	}
    	else {
    		return new ResponseEntity<HttpStatus>(HttpStatus.NOT_FOUND);
    	}
		
	}
	@PostMapping("/followeeList")
	public ResponseEntity<Optional<List<Users>>> followeeList(@RequestBody String email){
    	List<Follower> ls=folowerRepo.findAll();
    	List<Users> result=new ArrayList<>();
    	 for(int i=0;i<ls.size();i++) {
    		if(ls.get(i).getFollower().getEmail().equals(email)) {
    			Users u=ls.get(i).getFollowee();
    			u.setPassword(ls.get(i).getId().toString());
    			result.add(u);	
    		}
    	 }
    	 
    	 return new ResponseEntity<Optional<List<Users>>>(Optional.ofNullable(result),HttpStatus.OK);
	}
	@PostMapping("/followeeList/{id}")
	public ResponseEntity<HttpStatus> addfollowerList(@PathVariable Long id){
    	if(folowerRepoInt.existsById(id)) {
    		Optional<Follower> f =folowerRepoInt.findById(id);
    		Users u1=f.get().getFollower();
    		Users u2=f.get().getFollowee();
    		System.out.print(u2);
    		Follower follower=new Follower(u1,u2);
    		folowerRepo.save(follower);
    		return new ResponseEntity<HttpStatus>(HttpStatus.OK);
    	}
    	else {
    		return new ResponseEntity<HttpStatus>(HttpStatus.NOT_FOUND);
    	}
		
	}
	
	
	
	
	

}