package com.adp.capstrone.companycollaborationform.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.adp.capstrone.companycollaborationform.model.Users;
import com.adp.capstrone.companycollaborationform.repo.UserRepo;

@RestController
@CrossOrigin(origins="http://localhost:4200")

public class UserController {
	@Autowired
	UserRepo ur;
	@Autowired
	JdbcTemplate jt;
	
	@PostMapping("/api/register")
	public ResponseEntity<HttpStatus> register(@RequestBody Users user){
		System.out.println("called"+user);
		if(ur.save(user)) {
			return new ResponseEntity<HttpStatus>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<HttpStatus>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("/api/update")
	public ResponseEntity<HttpStatus> update(@RequestBody Users user){
		if(ur.update(user)) {
			return new ResponseEntity<HttpStatus>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<HttpStatus>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("/api/login")
	public ResponseEntity<Optional<Users>> login(@RequestBody Users user){
		String email=user.getEmail();
		String password=user.getPassword();
		Users store=ur.findByEmail(email);
		System.out.print("login call");
		if(store!=null&&store.getPassword().equals(password)) {
			return new ResponseEntity<Optional<Users>>(Optional.ofNullable(ur.findByEmail(email)),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Optional<Users>>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/api/searchemail")
	public ResponseEntity<HttpStatus> searchEmail(@RequestBody String email){
		if(ur.findByEmail(email)!=null) {
			return new ResponseEntity<HttpStatus>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<HttpStatus>(HttpStatus.NOT_FOUND);
		}
	}
	
	

}
