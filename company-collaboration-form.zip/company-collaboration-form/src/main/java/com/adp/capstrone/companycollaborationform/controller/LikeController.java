package com.adp.capstrone.companycollaborationform.controller;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.adp.capstrone.companycollaborationform.model.LikeComment;
import com.adp.capstrone.companycollaborationform.repo.LikeRepo;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="http://localhost:4200")
public class LikeController {
	
	@Autowired
	private EntityManager em;
	@Autowired
	private LikeRepo likeRepo;
	
	@GetMapping("/like/{post_id}/{email}")
	ResponseEntity<HttpStatus>checkNotLikeUserSave(@PathVariable("post_id") Integer post_id,@PathVariable("email") String email){
		List<LikeComment> allLike=likeRepo.findAll();
		 for (LikeComment l:allLike) {
			if(l.getEmail().equals(email)&& l.getPost_id()==post_id) {
				return new ResponseEntity<HttpStatus>(HttpStatus.CONFLICT);
			}
		 }
		 LikeComment likeComment=new LikeComment(post_id,email);
		 likeRepo.save(likeComment);
		return new ResponseEntity<HttpStatus>(HttpStatus.OK);	
	}
	
	@GetMapping("/like/{post_id}")
	ResponseEntity<Integer>numberOfLike(@PathVariable("post_id") Integer post_id){
		int count=0;
		List<LikeComment> allLike=likeRepo.findAll();
		 for (LikeComment l:allLike) {
			if(l.getPost_id()==post_id) {
				count++;
			}
		 }
		 return new ResponseEntity<Integer>(count,HttpStatus.OK);
		 	
	}
	
	
	
	

}
	