package com.adp.capstrone.companycollaborationform.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adp.capstrone.companycollaborationform.model.Comment;
import com.adp.capstrone.companycollaborationform.model.Follower;
import com.adp.capstrone.companycollaborationform.model.Users;
import com.adp.capstrone.companycollaborationform.repo.CommentRepo;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="http://localhost:4200")
public class CommentController {
	
	@Autowired
	private CommentRepo commentRepo;
	
	@Autowired
	private EntityManager em;
	
	@PostMapping("/comment")
	public ResponseEntity<Optional<Comment>> createComment(@RequestBody Comment comments){
		Comment cs=commentRepo.save(comments);
    	if(cs!=null) {
    		return new ResponseEntity<Optional<Comment>>(Optional.ofNullable(cs),HttpStatus.OK);
    	}
    	else {
    		return new ResponseEntity<Optional<Comment>>(HttpStatus.OK);
    	}	
	}
	@GetMapping("/comment/{id}")
	public ResponseEntity<Optional<List<Comment>>> allCommentList(@PathVariable Long id){
		List<Comment> ls=commentRepo.findAll();
    	List<Comment> result=new ArrayList<>();
    	 for(int i=0;i<ls.size();i++) {
    		if(ls.get(i).getPost_id().equals(id) ){
    			result.add(ls.get(i));	
    		}
    	 }
    	 System.out.println("data sent");
    	 return new ResponseEntity<Optional<List<Comment>>>(Optional.ofNullable(result),HttpStatus.OK);
	
	}
}
