package com.adp.capstrone.companycollaborationform;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.adp.capstrone.companycollaborationform.model.Comment;
import com.adp.capstrone.companycollaborationform.model.Follower;
import com.adp.capstrone.companycollaborationform.model.Post;
import com.adp.capstrone.companycollaborationform.model.Users;
import com.adp.capstrone.companycollaborationform.repo.CommentRepo;
import com.adp.capstrone.companycollaborationform.repo.FollowerRepo;
import com.adp.capstrone.companycollaborationform.repo.PostRepo;
import com.adp.capstrone.companycollaborationform.repo.UserRepo;

@SpringBootApplication
public class CompanyCollaborationFormApplication implements CommandLineRunner{
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private FollowerRepo followerRepo;
	
	@Autowired
    private PostRepo postrepo;
	
	@Autowired
	private CommentRepo comment;

	public static void main(String[] args) {
		SpringApplication.run(CompanyCollaborationFormApplication.class, args);
		
	}

	@Override
	public void run(String... args) throws Exception {
		Users user1=new Users("ABC","Kumar","abc@test.com","Test@123");
		Users user2=new Users("Mohan","Kumar","mohan@test.com","Mohan@123");
		Users user3=new Users("Rohan","Kumar","rohan@test.com","Rohan@123");
		Users user4=new Users("Sohan","Kumar","sohan@test.com","Sohan@123");
		Users user5=new Users("Test","Kumar","test@test.com","Test@123");
		userRepo.save(user1);
		userRepo.save(user2);
		userRepo.save(user3);
		userRepo.save(user4);
		userRepo.save(user5);
		
		Follower f1=new Follower(user1,user2);
		Follower f2=new Follower(user1,user3);
		Follower f3=new Follower(user1,user4);
		Follower f4=new Follower(user2,user4);
		Follower f5=new Follower(user5,user1);
		followerRepo.save(f1);
		followerRepo.save(f2);
		followerRepo.save(f3);
		followerRepo.save(f4);
		followerRepo.save(f5);
		
		Post post1=new Post(1001,"Sunny Day",new Date(), "test@test.com");
		Post post2=new Post(100,"You're not alone in this struggle!",new Date(), "test@test.com");
		Post post3=new Post(1067,"It can take a while to find your GROOVE on ADP-Post.",new Date(), "test@test.com");
		Post post4=new Post(1034,"We hope you find these helpful as you grow your Twitter audience!",new Date(), "test@test.com");
		postrepo.save(post1);
		postrepo.save(post2);
		postrepo.save(post3);
		postrepo.save(post4);
		
		Post post5=new Post(1002,"Snow Day",new Date(), "mohan@test.com");
		Post post6=new Post(1003,"You're not alone in this World!",new Date(), "mohan@test.com");
		Post post7=new Post(1068,"It can take a while to ",new Date(), "abc@test.com");
		Post post8=new Post(1035,"We hope you find these helpful ",new Date(), "abc@test.com");
		postrepo.save(post5);
		postrepo.save(post6);
		postrepo.save(post7);
		postrepo.save(post8);
		
		Comment co=new Comment(1001, "mohan@test.com", "Awesome");
		Comment co1=new Comment(1001, "abc@test.com", "I Like it");
		Comment co2=new Comment(1001, "rohan@test.com", "Here too");
		comment.save(co);
		comment.save(co1);
		comment.save(co2);
		
		
		
		
	}

}
