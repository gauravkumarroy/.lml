package com.adp.capstrone.companycollaborationform.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
public class Follower {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  Long id;

    @ManyToOne
    @JoinColumn(name = "followee")
    private Users followee;
    
    @ManyToOne
    @JoinColumn(name = "follower")
    private Users follower;

	public Follower() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Follower(Long id, Users followee, Users follower) {
		super();
		this.id = id;
		this.followee = followee;
		this.follower = follower;
	}
	public Follower( Users followee, Users follower) {
		this.followee = followee;
		this.follower = follower;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Users getFollowee() {
		return followee;
	}

	public void setFollowee(Users followee) {
		this.followee = followee;
	}

	public Users getFollower() {
		return follower;
	}

	public void setFollower(Users follower) {
		this.follower = follower;
	}

	@Override
	public String toString() {
		return "Follower [id=" + id + ", followee=" + followee + ", follower=" + follower + "]";
	}
    
    
}
