package com.adp.capstrone.companycollaborationform.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adp.capstrone.companycollaborationform.model.Follower;
import com.adp.capstrone.companycollaborationform.model.Users;

public interface FollowerRepo extends JpaRepository<Follower,Users> {

}
