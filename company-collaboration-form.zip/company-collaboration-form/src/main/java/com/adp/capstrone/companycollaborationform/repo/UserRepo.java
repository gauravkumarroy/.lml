package com.adp.capstrone.companycollaborationform.repo;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.adp.capstrone.companycollaborationform.model.Users;

@Repository

public class UserRepo {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	EntityManager em;
	
	public Users findByEmail(String email) {
		return em.find(Users.class, email);
	}
	
	public Boolean save(Users user) {
		jdbcTemplate.update(
			    "INSERT INTO users (fname,lname,email,password) VALUES (?, ?,?,?)",
			    user.getFname(),user.getLname(),user.getEmail(),user.getPassword()
			);
		return true;
	}
	
	public List<Users> findAll(){
		TypedQuery<Users> u=em.createNamedQuery("Find_all_user", Users.class);
		return u.getResultList();
	}
	public Boolean update(Users user) {
		Users users=em.find(Users.class, user.getEmail());
		if(users!=null) {
			if(user.getFname()!=null)
				users.setFname(user.getFname());
			if(user.getLname()!=null)
				users.setLname(user.getLname());
			if(user.getPassword()!=null)
				users.setPassword(user.getPassword());
			jdbcTemplate.update("UPDATE users SET fname = ?, lname = ?, email = ? ,password=? WHERE email = ?", new Object[] {users.getFname(), users.getLname(), users.getEmail(), users.getPassword(),users.getEmail()});
			return true;
		}
		else
			return false;
	}
	
	
	

}
