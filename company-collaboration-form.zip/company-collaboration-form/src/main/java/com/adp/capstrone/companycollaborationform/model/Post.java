package com.adp.capstrone.companycollaborationform.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.stereotype.Indexed;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value = {"createdAt"}, allowGetters = true)
public class Post {
    @Id
    private int id;
  
    private String title;
    
    private String email;

    private Date createdAt = new Date();

	public Post() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Post(int id, String title, Date createdAt,String email) {
		super();
		this.id = id;
		this.title = title;
		this.createdAt = createdAt;
		this.email=email;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	@Override
	public String toString() {
		return "Post [id=" + id + ", title=" + title + ", email=" + email + ",  createdAt=" + createdAt + "]";
	}

	
	

    

}
