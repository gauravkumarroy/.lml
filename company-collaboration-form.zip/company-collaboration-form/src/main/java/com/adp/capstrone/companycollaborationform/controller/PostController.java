package com.adp.capstrone.companycollaborationform.controller;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import com.adp.capstrone.companycollaborationform.model.Post;
import com.adp.capstrone.companycollaborationform.model.Users;
import com.adp.capstrone.companycollaborationform.repo.PostRepo;
import com.adp.capstrone.companycollaborationform.repo.PostRepoId;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins="http://localhost:4200")
public class PostController {

    @Autowired
    PostRepo postrepo;
    @Autowired
    PostRepoId pi;
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/posts")
    public List<Post> getAllPosts() {
        Sort sortByCreatedAtDesc = Sort.by(Sort.Direction.DESC, "createdAt");
        return postrepo.findAll(sortByCreatedAtDesc);
    }

    @PostMapping("/posts")
    public Post createPost( @RequestBody Post post) {
        return postrepo.save(post);
    }
    
    @PostMapping(value="/byemail")
	  public List<Post> getTodoById(@RequestBody String email) {
    	BeanPropertyRowMapper rowMapper = new BeanPropertyRowMapper(Post.class);
    	String sql="SELECT * FROM POST ";
    	List<Post> posts = jdbcTemplate.query(sql, rowMapper);
    	List<Post> res=new ArrayList<>();
    	for(Post post:posts) {
    		if(post.getEmail().equals(email)) {
    			res.add(post);
    		}
    	}

		return res;
		
	  }

    @PutMapping(value="/posts/{id}")
    public ResponseEntity<Post> updatePost(@PathVariable("id") int id,
                                            @RequestBody Post post) {
        return pi.findById(id)
                .map(postData -> {
                	postData.setTitle(post.getTitle());
                    Post updatedPost = postrepo.save(postData);
                    return ResponseEntity.ok().body(updatedPost);
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping(value="/posts/{id}")
    public ResponseEntity<?> deletePost(@PathVariable("id") Integer id) {
        return pi.findById(id)
                .map(posts -> {
                    pi.deleteById(id);
                    return ResponseEntity.ok().build();
                }).orElse(ResponseEntity.notFound().build());
        
    }
}
